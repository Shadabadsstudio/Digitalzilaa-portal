import streamlit as st
import sqlite3
import pandas as pd
from datetime import datetime, timedelta
import os
import urllib.parse

# --- DATABASE SETUP ---
def init_db():
    conn = sqlite3.connect('digital_zila.db', check_same_thread=False)
    c = conn.cursor()
    # Clients Table
    c.execute('''CREATE TABLE IF NOT EXISTS clients 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, quota INTEGER, logo TEXT)''')
    # Team Table
    c.execute('''CREATE TABLE IF NOT EXISTS team 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, role TEXT, whatsapp TEXT)''')
    # Tasks Table
    c.execute('''CREATE TABLE IF NOT EXISTS tasks 
                 (id INTEGER PRIMARY KEY AUTOINCREMENT, client_id INTEGER, brand_name TEXT, 
                  date TEXT, idea TEXT, hook TEXT, role TEXT, status TEXT, submission_link TEXT, 
                  FOREIGN KEY(client_id) REFERENCES clients(id))''')
    conn.commit()
    return conn

conn = init_db()

# --- THEME & STYLING ---
st.set_page_config(page_title="Digitalzilaa Portal", layout="wide")

st.markdown("""
    <style>
    .main {
        background-color: #FFFFFF;
    }
    .stButton>button {
        background-color: #007BFF;
        color: white;
        border-radius: 5px;
    }
    .stTextInput>div>div>input {
        border-radius: 5px;
    }
    .task-card {
        padding: 20px;
        border: 1px solid #EEEEEE;
        border-radius: 10px;
        margin-bottom: 10px;
        background-color: #F8F9FA;
    }
    h1, h2, h3 {
        color: #000000;
    }
    </style>
    """, unsafe_allow_html=True)

# --- NAVIGATION ---
st.sidebar.image("https://www.digitalzilaa.com/wp-content/uploads/2023/10/Digital-Zila-Logo.png", width=150)
menu = st.sidebar.radio("Navigation", ["Admin Panel", "Team Dashboard", "Task Approval"])

# --- ADMIN PANEL ---
if menu == "Admin Panel":
    st.title("Admin / Editor Panel")
    
    tabs = st.tabs(["Client Management", "Team Management", "Create Tasks"])
    
    with tabs[0]:
        st.subheader("Add New Client")
        with st.form("client_form"):
            c_name = st.text_input("Client Name")
            c_quota = st.number_input("Monthly Quota", min_value=1)
            c_logo = st.text_input("Logo URL (Optional)")
            if st.form_submit_button("Add Client"):
                conn.execute("INSERT INTO clients (name, quota, logo) VALUES (?, ?, ?)", (c_name, c_quota, c_logo))
                conn.commit()
                st.success(f"Added {c_name}")
        
        st.subheader("Existing Clients")
        clients_df = pd.read_sql("SELECT * FROM clients", conn)
        st.dataframe(clients_df, use_container_width=True)

    with tabs[1]:
        st.subheader("Add Team Member")
        with st.form("team_form"):
            t_name = st.text_input("Member Name")
            t_role = st.selectbox("Role", ["Designer", "AI Video Maker", "Video Editor"])
            t_whatsapp = st.text_input("WhatsApp Number (+91...)")
            if st.form_submit_button("Add Member"):
                conn.execute("INSERT INTO team (name, role, whatsapp) VALUES (?, ?, ?)", (t_name, t_role, t_whatsapp))
                conn.commit()
                st.success(f"Added {t_name}")
        
        st.subheader("Team Roster")
        team_df = pd.read_sql("SELECT * FROM team", conn)
        st.dataframe(team_df, use_container_width=True)

    with tabs[2]:
        st.subheader("Schedule Daily Tasks")
        clients = pd.read_sql("SELECT id, name FROM clients", conn)
        client_options = {row['name']: row['id'] for idx, row in clients.iterrows()}
        
        with st.form("task_form"):
            selected_client = st.selectbox("Select Brand", list(client_options.keys()))
            t_date = st.date_input("Date")
            t_idea = st.text_area("Content Idea")
            t_hook = st.text_input("The Hook")
            t_role = st.selectbox("Assign to Wing", ["Designer", "AI Video Maker", "Video Editor"])
            if st.form_submit_button("Publish Task"):
                conn.execute("""INSERT INTO tasks (client_id, brand_name, date, idea, hook, role, status) 
                               VALUES (?, ?, ?, ?, ?, ?, ?)""", 
                             (client_options[selected_client], selected_client, str(t_date), t_idea, t_hook, t_role, "Pending"))
                conn.commit()
                st.success("Task Published!")

        st.divider()
        st.subheader("WhatsApp Daily Alerts")
        if st.button("Generate Today's WhatsApp Links"):
            today_str = str(datetime.now().date())
            tasks_today = pd.read_sql(f"SELECT * FROM tasks WHERE date = '{today_str}'", conn)
            team_members = pd.read_sql("SELECT * FROM team", conn)
            
            for index, member in team_members.iterrows():
                member_tasks = tasks_today[tasks_today['role'] == member['role']]
                if not member_tasks.empty:
                    msg = f"Hi {member['name']}, your tasks for today are:\n"
                    for i, (idx, task) in enumerate(member_tasks.iterrows()):
                        msg += f"{i+1}. [{task['brand_name']}] - {task['idea']}\n"
                    msg += "Please update status on the portal."
                    
                    encoded_msg = urllib.parse.quote(msg)
                    wa_link = f"https://wa.me/{member['whatsapp']}?text={encoded_msg}"
                    st.markdown(f"[Send to {member['name']} ({member['role']})]({wa_link})")

# --- TEAM DASHBOARD ---
elif menu == "Team Dashboard":
    st.title("Team Dashboard")
    role = st.sidebar.selectbox("Select Your Role", ["Designer", "AI Video Maker", "Video Editor"])
    
    st.write(f"Showing tasks for: **{role}**")
    
    today = datetime.now().date()
    dates_to_show = [str(today), str(today + timedelta(days=1)), str(today + timedelta(days=2))]
    
    for d_str in dates_to_show:
        st.subheader(f"📅 {d_str}")
        tasks_df = pd.read_sql(f"SELECT * FROM tasks WHERE role = '{role}' AND date = '{d_str}'", conn)
        
        if tasks_df.empty:
            st.info("No tasks scheduled for this day.")
        else:
            for idx, task in tasks_df.iterrows():
                with st.container():
                    st.markdown(f"""
                    <div class="task-card">
                        <b>{task['brand_name']}</b><br>
                        <i>Hook: {task['hook']}</i><br>
                        <p>{task['idea']}</p>
                        <p>Status: <code>{task['status']}</code></p>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    if task['status'] in ["Pending", "Rejected"]:
                        with st.expander("Submit Performance"):
                            link = st.text_input("Submission Link", key=f"link_{task['id']}")
                            if st.button("Submit for Review", key=f"btn_{task['id']}"):
                                if link:
                                    conn.execute("UPDATE tasks SET status='Under Review', submission_link=? WHERE id=?", (link, task['id']))
                                    conn.commit()
                                    st.success("Submitted!")
                                    st.rerun()
                                else:
                                    st.error("Please provide a link.")

# --- TASK APPROVAL ---
elif menu == "Task Approval":
    st.title("Admin Approval Page")
    
    under_review = pd.read_sql("SELECT * FROM tasks WHERE status = 'Under Review'", conn)
    
    if under_review.empty:
        st.success("Zero tasks awaiting review! Good job.")
    else:
        for idx, task in under_review.iterrows():
            with st.expander(f"{task['brand_name']} - {task['role']} Submission"):
                st.write(f"**Idea:** {task['idea']}")
                st.write(f"**Submission:** [View Work]({task['submission_link']})")
                
                col1, col2 = st.columns(2)
                with col1:
                    if st.button("✅ Approve", key=f"app_{task['id']}"):
                        conn.execute("UPDATE tasks SET status='Approved' WHERE id=?", (task['id'],))
                        conn.commit()
                        st.success("Task Approved!")
                        st.rerun()
                with col2:
                    if st.button("❌ Reject", key=f"rej_{task['id']}"):
                        conn.execute("UPDATE tasks SET status='Rejected' WHERE id=?", (task['id'],))
                        conn.commit()
                        st.info("Task Rejected.")
                        st.rerun()

conn.close()
