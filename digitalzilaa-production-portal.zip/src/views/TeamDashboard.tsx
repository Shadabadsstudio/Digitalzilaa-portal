import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot,
  updateDoc,
  doc,
  serverTimestamp
} from 'firebase/firestore';
import { Task, UserRole, TaskStatus } from '../types';
import { 
  Clock, 
  Calendar, 
  ChevronRight, 
  ExternalLink, 
  CheckCircle2, 
  AlertCircle,
  Play
} from 'lucide-react';
import { format, addDays, isSameDay } from 'date-fns';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface TeamDashboardProps {
  role: UserRole;
  userId: string;
}

export default function TeamDashboard({ role, userId }: TeamDashboardProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [submissionLink, setSubmissionLink] = useState('');

  const today = new Date();
  const tomorrow = addDays(today, 1);
  const dayAfter = addDays(today, 2);

  const dates = [
    { label: 'Today', date: today, id: format(today, 'yyyy-MM-dd') },
    { label: 'Tomorrow', date: tomorrow, id: format(tomorrow, 'yyyy-MM-dd') },
    { label: 'Day After', date: dayAfter, id: format(dayAfter, 'yyyy-MM-dd') }
  ];

  useEffect(() => {
    // Only fetch tasks for their role
    const q = query(
      collection(db, 'tasks'),
      where('role', '==', role)
    );
    
    const unsub = onSnapshot(q, (snap) => {
      setTasks(snap.docs.map(d => ({ id: d.id, ...d.data() } as Task)));
    });
    return unsub;
  }, [role]);

  const submitTask = async (taskId: string) => {
    if (!submissionLink) return;
    try {
      await updateDoc(doc(db, 'tasks', taskId), {
        submissionLink,
        status: 'under_review',
        updatedAt: serverTimestamp()
      });
      setActiveTask(null);
      setSubmissionLink('');
    } catch (err) {
      console.error(err);
      alert("Failed to submit task.");
    }
  };

  const getStatusIcon = (status: TaskStatus) => {
    switch (status) {
      case 'approved': return <CheckCircle2 className="w-4 h-4 text-green-500" />;
      case 'rejected': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'under_review': return <Clock className="w-4 h-4 text-yellow-500" />;
      default: return <Clock className="w-4 h-4 text-white/20" />;
    }
  };

  return (
    <div className="space-y-12">
      <header>
        <div className="text-[10px] text-slate-500 uppercase tracking-[0.3em] mb-1">{role} Overview</div>
        <h2 className="text-3xl font-bold tracking-tight">Your Roadmap</h2>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {dates.map((day) => {
          const dayTasks = tasks.filter(t => t.date === day.id);
          
          return (
            <div key={day.id} className="flex flex-col">
              <div className="flex items-baseline justify-between mb-6 outline-none">
                <h3 className="section-title">{day.label}</h3>
                <span className="mono-label">{format(day.date, 'MMM dd')}</span>
              </div>

              <div className="space-y-4">
                {dayTasks.length === 0 ? (
                  <div className="h-32 border border-dashed border-slate-800 rounded-xl flex items-center justify-center text-[10px] text-slate-600 uppercase tracking-widest">
                    No tasks scheduled
                  </div>
                ) : (
                  dayTasks.map(task => (
                    <motion.div 
                      layoutId={task.id}
                      key={task.id} 
                      onClick={() => setActiveTask(task)}
                      className={cn(
                        "dashboard-card group cursor-pointer",
                        task.status === 'approved' && "opacity-50"
                      )}
                    >
                      <div className="card-accent" />
                      
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-8 h-8 rounded bg-white text-black flex items-center justify-center font-bold text-xs uppercase">
                           {task.clientName.substring(0, 2)}
                        </div>
                        <span className="text-xs font-bold tracking-widest uppercase">{task.clientName}</span>
                      </div>

                      <p className="text-sm text-slate-300 mb-4 line-clamp-2">
                        {task.idea}
                      </p>

                      <div className="flex items-center justify-between mono-label">
                        <span>{task.role} / {task.id.slice(-4).toUpperCase()}</span>
                        <span className={cn(
                          "transition-colors",
                          task.status === 'under_review' && "text-yellow-500",
                          task.status === 'approved' && "text-green-500",
                          task.status === 'rejected' && "text-red-500",
                          task.status === 'pending' && "text-white"
                        )}>
                          {task.status.replace('_', ' ')}
                        </span>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Task Detail Modal */}
      {activeTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#0A0A0A] border border-white/10 rounded-2xl w-full max-w-lg overflow-hidden flex flex-col"
          >
            <div className="p-8 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center">
                    <Play className="w-6 h-6 text-black fill-black" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xl">{activeTask.clientName}</h3>
                    <p className="text-sm text-white/40">{activeTask.date}</p>
                  </div>
                </div>
                <button onClick={() => setActiveTask(null)} className="text-white/40 hover:text-white">✕</button>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Hook</label>
                <p className="text-lg font-medium">{activeTask.hook || 'N/A'}</p>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Idea & Instructions</label>
                <p className="text-white/70 leading-relaxed max-h-48 overflow-y-auto whitespace-pre-wrap pr-2">
                  {activeTask.idea}
                </p>
              </div>

              {activeTask.adminComments && (
                <div className="p-4 bg-red-500/5 border border-red-500/20 rounded-xl space-y-1">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-red-500/60">Admin Feedback</label>
                  <p className="text-sm text-red-100">{activeTask.adminComments}</p>
                </div>
              )}

              {activeTask.status !== 'approved' && (
                <div className="space-y-4 pt-4 border-t border-white/5">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Submission Link</label>
                    <input 
                      className="input-field w-full text-sm" 
                      placeholder="e.g. Drive link, YouTube link..." 
                      value={submissionLink}
                      onChange={e => setSubmissionLink(e.target.value)}
                    />
                  </div>
                  <button 
                    onClick={() => submitTask(activeTask.id)}
                    className="w-full btn-primary h-12 flex items-center justify-center gap-2"
                  >
                    Complete & Submit for Review
                  </button>
                </div>
              )}

              {activeTask.status === 'approved' && (
                <div className="p-4 bg-green-500/5 border border-green-500/20 rounded-xl flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <p className="text-sm text-green-500 font-medium">Task Approved. Great job!</p>
                  {activeTask.submissionLink && (
                    <a href={activeTask.submissionLink} target="_blank" rel="noreferrer" className="ml-auto text-white/40 hover:text-white">
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
