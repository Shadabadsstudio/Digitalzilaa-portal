import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot,
  updateDoc,
  doc,
  serverTimestamp
} from 'firebase/firestore';
import { Task } from '../types';
import { 
  CheckCircle2, 
  XCircle, 
  ExternalLink, 
  MessageSquare,
  Clock,
  Layout
} from 'lucide-react';
import { cn } from '../lib/utils';
import { format } from 'date-fns';

export default function TaskApproval() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTask, setActiveTask] = useState<Task | null>(null);
  const [comments, setComments] = useState('');

  useEffect(() => {
    const q = query(
      collection(db, 'tasks'),
      where('status', '==', 'under_review')
    );
    
    const unsub = onSnapshot(q, (snap) => {
      setTasks(snap.docs.map(d => ({ id: d.id, ...d.data() } as Task)));
    });
    return unsub;
  }, []);

  const handleAction = async (taskId: string, status: 'approved' | 'rejected') => {
    try {
      await updateDoc(doc(db, 'tasks', taskId), {
        status,
        adminComments: comments,
        updatedAt: serverTimestamp()
      });
      setActiveTask(null);
      setComments('');
    } catch (err) {
      console.error(err);
      alert("Failed to update task.");
    }
  };

  return (
    <div className="space-y-12">
      <header>
        <div className="text-[10px] text-slate-500 uppercase tracking-[0.3em] mb-1">System Audit</div>
        <h2 className="text-3xl font-bold tracking-tight">Awaiting Approval</h2>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tasks.length === 0 ? (
          <div className="col-span-full h-40 border border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center text-slate-600 gap-2">
            <Layout className="w-8 h-8 opacity-20" />
            <p className="text-xs uppercase tracking-widest font-bold">No tasks under review</p>
          </div>
        ) : (
          tasks.map(task => (
            <div 
              key={task.id} 
              onClick={() => setActiveTask(task)}
              className="dashboard-card cursor-pointer group"
            >
              <div className="card-accent bg-yellow-500" />
              
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 rounded bg-slate-800 text-white flex items-center justify-center font-bold text-xs uppercase">
                   {task.clientName.substring(0, 2)}
                </div>
                <span className="text-xs font-bold tracking-widest uppercase">{task.clientName}</span>
              </div>

              <div className="space-y-1">
                <p className="text-sm font-bold text-white line-clamp-1">{task.hook || 'Untitled Content'}</p>
                <p className="mono-label">ASSIGNED TO: {task.role}</p>
              </div>

              <div className="flex items-center justify-between pt-4 mono-label">
                <span>DUE: {task.date}</span>
                <span className="text-yellow-500">UNDER REVIEW</span>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Review Side Panel / Modal */}
      {activeTask && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#0A0A0A] border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-8 space-y-8">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-1">Production Review</p>
                  <h2 className="text-2xl font-bold">{activeTask.clientName}</h2>
                </div>
                <button onClick={() => setActiveTask(null)} className="text-white/40 hover:text-white">✕</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-6">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Hook / Title</label>
                    <p className="text-base font-medium">{activeTask.hook || 'N/A'}</p>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Instructions</label>
                    <p className="text-sm text-white/60 leading-relaxed">{activeTask.idea}</p>
                  </div>
                </div>

                <div className="space-y-6 bg-white/[0.02] p-6 rounded-2xl border border-white/5">
                   <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Submission</label>
                    {activeTask.submissionLink ? (
                      <a 
                        href={activeTask.submissionLink} 
                        target="_blank" 
                        rel="noreferrer"
                        className="flex items-center justify-between p-3 bg-black rounded-lg border border-white/10 hover:border-white/30 transition-all"
                      >
                        <span className="text-xs truncate max-w-[150px]">{activeTask.submissionLink}</span>
                        <ExternalLink className="w-4 h-4 text-white/40" />
                      </a>
                    ) : (
                      <p className="text-xs text-red-400">No link provided</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-white/40">Feedback / Comments</label>
                    <textarea 
                      className="input-field w-full h-24 text-sm resize-none"
                      placeholder="Add comments for rejection or notes for approval..."
                      value={comments}
                      onChange={e => setComments(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/5">
                <button 
                  onClick={() => handleAction(activeTask.id, 'rejected')}
                  className="h-12 rounded-xl flex items-center justify-center gap-2 text-red-500 border border-red-500/20 hover:bg-red-500/5 transition-all"
                >
                  <XCircle className="w-5 h-5" />
                  Reject with Feedback
                </button>
                <button 
                  onClick={() => handleAction(activeTask.id, 'approved')}
                  className="h-12 bg-white text-black rounded-xl flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
                >
                  <CheckCircle2 className="w-5 h-5" />
                  Approve Production
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
