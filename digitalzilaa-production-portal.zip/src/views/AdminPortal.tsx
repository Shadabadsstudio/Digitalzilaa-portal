import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  onSnapshot,
  setDoc,
  doc,
  serverTimestamp,
  deleteDoc
} from 'firebase/firestore';
import { Client, TeamMember, Task, UserRole } from '../types';
import { 
  Plus, 
  Trash2, 
  Users, 
  Briefcase, 
  Send, 
  Calendar as CalendarIcon,
  Link as LinkIcon,
  MessageSquare
} from 'lucide-react';
import { format } from 'date-fns';
import { handleFirestoreError } from '../lib/error-handler';
import { OperationType } from '../types';

export default function AdminPortal() {
  const [clients, setClients] = useState<Client[]>([]);
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [isAddingClient, setIsAddingClient] = useState(false);
  const [isAddingMember, setIsAddingMember] = useState(false);
  const [isAddingTask, setIsAddingTask] = useState(false);

  // Forms
  const [clientForm, setClientForm] = useState({ name: '', monthlyQuotas: '' });
  const [memberForm, setMemberForm] = useState({ name: '', role: 'Designer', whatsappNumber: '', email: '' });
  const [taskForm, setTaskForm] = useState({ 
    clientId: '', 
    date: format(new Date(), 'yyyy-MM-dd'),
    idea: '',
    hook: '',
    role: 'Designer' as UserRole
  });

  useEffect(() => {
    const unsubClients = onSnapshot(collection(db, 'clients'), (snap) => {
      setClients(snap.docs.map(d => ({ id: d.id, ...d.data() } as Client)));
    });
    const unsubTeam = onSnapshot(collection(db, 'teamMembers'), (snap) => {
      setTeam(snap.docs.map(d => ({ id: d.id, ...d.data() } as TeamMember)));
    });
    return () => { unsubClients(); unsubTeam(); };
  }, []);

  const addClient = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'clients'), {
        ...clientForm,
        monthlyQuotas: Number(clientForm.monthlyQuotas),
        createdAt: serverTimestamp()
      });
      setClientForm({ name: '', monthlyQuotas: '' });
      setIsAddingClient(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'clients');
    }
  };

  const addMember = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'teamMembers'), {
        ...memberForm,
        createdAt: serverTimestamp()
      });
      setMemberForm({ name: '', role: 'Designer', whatsappNumber: '', email: '' });
      setIsAddingMember(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'teamMembers');
    }
  };

  const createTask = async (e: React.FormEvent) => {
    e.preventDefault();
    const selectedClient = clients.find(c => c.id === taskForm.clientId);
    if (!selectedClient) return;

    try {
      await addDoc(collection(db, 'tasks'), {
        ...taskForm,
        clientName: selectedClient.name,
        clientLogoUrl: selectedClient.logoUrl || '',
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setTaskForm({ ...taskForm, idea: '', hook: '' });
      setIsAddingTask(false);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'tasks');
    }
  };

  const sendAutomation = async (member: TeamMember) => {
    try {
      // Get today's tasks for this member role
      const q = query(collection(db, 'tasks'));
      const snap = await getDocs(q);
      const memberTasks = snap.docs
        .map(d => ({ id: d.id, ...d.data() } as Task))
        .filter(t => t.role === member.role && t.date === format(new Date(), 'yyyy-MM-dd'));

      if (memberTasks.length === 0) {
        alert("No tasks for today for this member's role.");
        return;
      }

      const res = await fetch('/api/whatsapp/send-daily', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ teamMember: member, tasks: memberTasks })
      });
      const data = await res.json();
      alert(data.message);
    } catch (err) {
      console.error(err);
      alert("Failed to send WhatsApp message.");
    }
  };

  return (
    <div className="space-y-12">
      <header>
        <div className="text-[10px] text-slate-500 uppercase tracking-[0.3em] mb-1">Administrative Control</div>
        <h2 className="text-3xl font-bold tracking-tight">Portal Management</h2>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Client Management */}
        <section className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="section-title">Clients</h3>
            <button onClick={() => setIsAddingClient(!isAddingClient)} className="btn-secondary py-1 h-8">
              {isAddingClient ? 'Cancel' : 'Add Client'}
            </button>
          </div>

          {isAddingClient && (
            <form onSubmit={addClient} className="dashboard-card space-y-4">
              <div className="card-accent" />
              <input 
                className="input-field w-full" 
                placeholder="Client Name" 
                value={clientForm.name}
                onChange={e => setClientForm({...clientForm, name: e.target.value})}
                required
              />
              <input 
                type="number"
                className="input-field w-full" 
                placeholder="Monthly Quota" 
                value={clientForm.monthlyQuotas}
                onChange={e => setClientForm({...clientForm, monthlyQuotas: e.target.value})}
                required
              />
              <button className="w-full btn-primary h-10">Save Client</button>
            </form>
          )}

          <div className="space-y-2">
            {clients.map(client => (
              <div key={client.id} className="p-4 bg-[#111111] border border-slate-800 rounded-xl flex items-center justify-between group">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded bg-white text-black flex items-center justify-center font-bold text-xs">
                    {client.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-bold tracking-tight">{client.name}</p>
                    <p className="mono-label">{client.monthlyQuotas} POSTS / MONTH</p>
                  </div>
                </div>
                <button 
                  onClick={() => deleteDoc(doc(db, 'clients', client.id))}
                  className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-500 transition-all"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </section>

        {/* Team Management */}
        <section className="space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="section-title">Team members</h3>
            <button onClick={() => setIsAddingMember(!isAddingMember)} className="btn-secondary py-1 h-8">
              {isAddingMember ? 'Cancel' : 'Add Member'}
            </button>
          </div>

          {isAddingMember && (
            <form onSubmit={addMember} className="dashboard-card space-y-4">
              <div className="card-accent" />
              <input 
                className="input-field w-full" 
                placeholder="Full Name" 
                value={memberForm.name}
                onChange={e => setMemberForm({...memberForm, name: e.target.value})}
                required
              />
              <input 
                className="input-field w-full" 
                placeholder="Auth Email" 
                value={memberForm.email}
                onChange={e => setMemberForm({...memberForm, email: e.target.value})}
                required
              />
              <input 
                className="input-field w-full" 
                placeholder="WhatsApp (+91...)" 
                value={memberForm.whatsappNumber}
                onChange={e => setMemberForm({...memberForm, whatsappNumber: e.target.value})}
                required
              />
              <select 
                className="input-field w-full"
                value={memberForm.role}
                onChange={e => setMemberForm({...memberForm, role: e.target.value as any})}
              >
                <option value="Designer">Designer</option>
                <option value="Video Editor">Video Editor</option>
                <option value="AI Video Maker">AI Video Maker</option>
              </select>
              <button className="w-full btn-primary h-10">Add Member</button>
            </form>
          )}

          <div className="space-y-2">
            {team.map(member => (
              <div key={member.id} className="p-4 bg-[#111111] border border-slate-800 rounded-xl flex items-center justify-between group">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full border border-slate-700 bg-slate-800 flex items-center justify-center font-bold text-[10px]">
                    {member.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-bold tracking-tight">{member.name}</p>
                    <p className="mono-label">{member.role} • {member.whatsappNumber}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                   <button 
                    onClick={() => sendAutomation(member)}
                    className="p-2 border border-slate-800 hover:border-slate-600 rounded text-slate-500 hover:text-white transition-all"
                    title="Notify Member"
                   >
                    <Send className="w-4 h-4" />
                   </button>
                   <button 
                    onClick={() => deleteDoc(doc(db, 'teamMembers', member.id))}
                    className="opacity-0 group-hover:opacity-100 p-2 text-slate-700 hover:text-red-500 transition-all"
                   >
                    <Trash2 className="w-4 h-4" />
                   </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Task Creation Section */}
      <section className="space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <h3 className="section-title">CONTENT SCHEDULER</h3>
          <button onClick={() => setIsAddingTask(!isAddingTask)} className="btn-primary flex items-center gap-2 h-10">
            <Plus className="w-4 h-4" />
            New Task
          </button>
        </div>

        {isAddingTask && (
          <form onSubmit={createTask} className="dashboard-card max-w-2xl grid grid-cols-2 gap-6">
            <div className="card-accent" />
            <div className="col-span-2">
              <label className="mono-label mb-2 block text-white">Select Brand</label>
              <select 
                className="input-field w-full"
                value={taskForm.clientId}
                onChange={e => setTaskForm({...taskForm, clientId: e.target.value})}
                required
              >
                <option value="">Select Brand</option>
                {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
            <div>
              <label className="mono-label mb-2 block text-white">Production Date</label>
              <input 
                type="date"
                className="input-field w-full"
                value={taskForm.date}
                onChange={e => setTaskForm({...taskForm, date: e.target.value})}
                required
              />
            </div>
            <div>
              <label className="mono-label mb-2 block text-white">Execution Wing</label>
              <select 
                className="input-field w-full"
                value={taskForm.role}
                onChange={e => setTaskForm({...taskForm, role: e.target.value as any})}
                required
              >
                <option value="Designer">Designer</option>
                <option value="Video Editor">Video Editor</option>
                <option value="AI Video Maker">AI Video Maker</option>
              </select>
            </div>
            <div className="col-span-2">
              <label className="mono-label mb-2 block text-white">Hook / Primary Tagline</label>
              <input 
                className="input-field w-full"
                placeholder="Enter compelling hook..."
                value={taskForm.hook}
                onChange={e => setTaskForm({...taskForm, hook: e.target.value})}
              />
            </div>
            <div className="col-span-2">
              <label className="mono-label mb-2 block text-white">Production Brief</label>
              <textarea 
                className="input-field w-full h-40 resize-none"
                placeholder="Technical specifications, visual references..."
                value={taskForm.idea}
                onChange={e => setTaskForm({...taskForm, idea: e.target.value})}
                required
              />
            </div>
            <button className="col-span-2 btn-primary h-12">Commit to Production</button>
          </form>
        )}
      </section>
    </div>
  );
}
