export type UserRole = "Designer" | "AI Video Maker" | "Video Editor" | "Admin";

export interface Client {
  id: string;
  name: string;
  monthlyQuotas: number;
  logoUrl?: string;
  createdAt: any;
}

export interface TeamMember {
  id: string;
  name: string;
  role: UserRole;
  whatsappNumber: string;
  userId?: string;
  email: string;
}

export type TaskStatus = "pending" | "under_review" | "approved" | "rejected";

export interface Task {
  id: string;
  clientId: string;
  clientName: string;
  clientLogoUrl?: string;
  date: string; // YYYY-MM-DD
  idea: string;
  hook?: string;
  status: TaskStatus;
  role: UserRole;
  assignedTo?: string; // userId
  submissionLink?: string;
  adminComments?: string;
  createdAt: any;
  updatedAt: any;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}
