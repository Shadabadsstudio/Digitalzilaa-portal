import React from 'react';
import { User } from 'firebase/auth';
import { UserRole } from '../types';
import { 
  Users, 
  LayoutDashboard, 
  Calendar, 
  CheckSquare, 
  Settings, 
  PlusCircle, 
  Play,
  LogOut
} from 'lucide-react';
import { cn } from '../lib/utils';
import { auth } from '../lib/firebase';
import { signOut } from 'firebase/auth';

interface SidebarProps {
  role: UserRole;
  activeView: string;
  onViewChange: (view: any) => void;
  user: User;
}

export default function Sidebar({ role, activeView, onViewChange, user }: SidebarProps) {
  const isAdmin = role === 'Admin';
  
  const navItems = [
    { id: 'admin', label: 'Management', icon: Users, show: isAdmin },
    { id: 'team', label: 'My Dashboard', icon: LayoutDashboard, show: true },
    { id: 'approval', label: 'Approvals', icon: CheckSquare, show: isAdmin },
    { id: 'settings', label: 'Settings', icon: Settings, show: true },
  ];

  return (
    <aside className="w-64 bg-[#050505] flex flex-col border-r border-slate-800">
      <div className="p-8">
        <h1 className="text-2xl font-black tracking-tighter uppercase mb-12">Digitalzilaa</h1>
        
        <nav className="space-y-6">
          {navItems.filter(i => i.show).map((item) => (
            <button
              key={item.id}
              onClick={() => onViewChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 transition-colors group text-left",
                activeView === item.id 
                  ? "text-white" 
                  : "text-slate-500 hover:text-white"
              )}
            >
              <div className={cn(
                "w-2 h-2 rounded-full transition-all",
                activeView === item.id 
                  ? "bg-white" 
                  : "bg-transparent border border-slate-700 group-hover:border-slate-500"
              )} />
              <span className="text-sm font-bold uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-8 space-y-6">
        <div className="p-4 bg-slate-900/30 border border-slate-800 rounded-lg">
          <div className="text-[10px] text-slate-500 uppercase tracking-widest mb-2">Automation Status</div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.4)]"></div>
            <span className="text-[10px] font-mono text-slate-300">WhatsApp Active</span>
          </div>
        </div>

        <div className="flex items-center gap-3 group">
          <div className="w-10 h-10 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs">
            {user.displayName?.split(' ').map(n => n[0]).join('') || user.email?.[0].toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold truncate">{user.displayName || user.email?.split('@')[0]}</p>
            <p className="text-[10px] font-mono text-slate-500 uppercase">{role}</p>
          </div>
          <button 
            onClick={() => signOut(auth)}
            className="text-slate-500 hover:text-red-500 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
