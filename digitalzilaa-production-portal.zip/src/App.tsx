import React, { useEffect, useState } from 'react';
import { auth, db, signInWithGoogle } from './lib/firebase';
import { onAuthStateChanged, User, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { UserRole, TeamMember } from './types';
import Sidebar from './components/Sidebar';
import AdminPortal from './views/AdminPortal';
import TeamDashboard from './views/TeamDashboard';
import TaskApproval from './views/TaskApproval';
import { Layout, Play, LogIn, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<'admin' | 'team' | 'approval' | 'settings'>('team');

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        // Bootstrap admin
        if (u.email === 'anshadab65@gmail.com') {
          const adminDoc = doc(db, 'admins', u.uid);
          const snap = await getDoc(adminDoc);
          if (!snap.exists()) {
            await setDoc(adminDoc, { email: u.email });
          }
          setRole('Admin');
          setView('admin');
        } else {
          // Check if admin
          const adminDoc = doc(db, 'admins', u.uid);
          const adminSnap = await getDoc(adminDoc);
          if (adminSnap.exists()) {
            setRole('Admin');
            setView('admin');
          } else {
            // Check team member role
            const memberDoc = doc(db, 'teamMembers', u.uid);
            const memberSnap = await getDoc(memberDoc);
            if (memberSnap.exists()) {
              setRole(memberSnap.data().role as UserRole);
              setView('team');
            } else {
              setRole(null);
            }
          }
        }
      } else {
        setRole(null);
      }
      setLoading(false);
    });
    return unsub;
  }, []);

  if (loading) {
    return (
      <div className="h-screen flex items-center justify-center bg-black">
        <Loader2 className="w-8 h-8 animate-spin text-white/50" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-screen flex items-center justify-center bg-black px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-md w-full text-center space-y-8"
        >
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center">
              <Play className="w-8 h-8 text-black fill-black" />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-bold tracking-tight">Digitalzilaa Portal</h1>
            <p className="text-white/50">High-performance production management</p>
          </div>
          <button 
            onClick={signInWithGoogle}
            className="w-full flex items-center justify-center gap-3 bg-white text-black h-12 rounded-xl font-medium hover:opacity-90 transition-opacity"
          >
            <LogIn className="w-5 h-5" />
            Sign in with Google
          </button>
        </motion.div>
      </div>
    );
  }

  if (user && !role && user.email !== 'anshadab65@gmail.com') {
    return (
      <div className="h-screen flex items-center justify-center bg-black p-4 text-center">
        <div className="space-y-4">
          <p className="text-xl">Access Restricted</p>
          <p className="text-white/50 max-w-sm">
            Your account ({user.email}) is not authorized yet. 
            Please contact the administrator to assign your role.
          </p>
          <button onClick={() => signOut(auth)} className="btn-secondary">Sign Out</button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-black overflow-hidden">
      <Sidebar 
        role={role!} 
        activeView={view} 
        onViewChange={setView} 
        user={user}
      />
      
      <main className="flex-1 overflow-y-auto bg-black border-l border-white/5">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2 }}
            className="p-8"
          >
            {view === 'admin' && <AdminPortal />}
            {view === 'team' && <TeamDashboard role={role!} userId={user.uid} />}
            {view === 'approval' && <TaskApproval />}
            {view === 'settings' && (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold">Settings</h2>
                <div className="dashboard-card max-w-md">
                   <p className="text-white/70 mb-4">Signed in as: {user.email}</p>
                   <button onClick={() => signOut(auth)} className="w-full btn-secondary text-red-500 border-red-500/20 hover:bg-red-500/5">Sign Out</button>
                </div>
              </div>
            )}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
}
