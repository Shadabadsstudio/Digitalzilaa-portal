import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Mock WhatsApp Integration
  app.post("/api/whatsapp/send-daily", async (req, res) => {
    const { teamMember, tasks } = req.body;
    console.log(`[MOCK WHATSAPP] Sending to ${teamMember.name} (${teamMember.whatsappNumber})`);
    const message = `Hi ${teamMember.name}, your tasks for today are:\n${tasks.map((t: any, i: number) => `${i + 1}. [${t.clientName}] - ${t.idea}`).join('\n')}\nPlease update status on the portal.`;
    console.log(`Message: ${message}`);
    
    // In a real app, you'd use Twilio here:
    // await twilio.messages.create({ body: message, to: teamMember.whatsappNumber, from: '...' });

    res.json({ success: true, message: "WhatsApp message sent (simulated)" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
