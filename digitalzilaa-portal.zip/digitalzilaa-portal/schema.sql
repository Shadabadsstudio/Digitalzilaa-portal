-- Digitalzilaa Portal — SQLite schema
-- Auto-applied on app startup by app.py (init_db).

CREATE TABLE IF NOT EXISTS clients (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    name         TEXT NOT NULL UNIQUE,
    monthly_quota INTEGER NOT NULL DEFAULT 0,
    logo_path    TEXT,
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS team_members (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL,
    role            TEXT NOT NULL CHECK(role IN ('Designer','AI Video Maker','Video Editor','Admin')),
    whatsapp_number TEXT NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tasks (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id     INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    assignee_role TEXT NOT NULL CHECK(assignee_role IN ('Designer','AI Video Maker','Video Editor')),
    task_date     DATE NOT NULL,
    hook          TEXT NOT NULL,
    idea          TEXT,
    status        TEXT NOT NULL DEFAULT 'Pending'
                    CHECK(status IN ('Pending','In Progress','Under Review','Approved','Rejected')),
    submission_link TEXT,
    review_comment  TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_tasks_date    ON tasks(task_date);
CREATE INDEX IF NOT EXISTS idx_tasks_role    ON tasks(assignee_role);
CREATE INDEX IF NOT EXISTS idx_tasks_status  ON tasks(status);

CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

CREATE TABLE IF NOT EXISTS notification_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    sent_date  DATE NOT NULL,
    member_id  INTEGER REFERENCES team_members(id) ON DELETE SET NULL,
    channel    TEXT NOT NULL DEFAULT 'whatsapp',
    status     TEXT NOT NULL,
    detail     TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
