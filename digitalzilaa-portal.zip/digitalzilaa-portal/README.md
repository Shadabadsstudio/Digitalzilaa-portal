# Digitalzilaa Portal

Production management portal for Digitalzilaa agency. Streamlit + SQLite + WhatsApp automation.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                 # then edit credentials
streamlit run app.py
```

The SQLite database (`digitalzilaa.db`) and uploaded client logos (`uploads/`) are
created on first run and persist across restarts.

## Default login

`admin / change-me` — change in `.env` (`ADMIN_USERNAME`, `ADMIN_PASSWORD`).

## Pages

- **Admin → Clients** — add/edit clients, monthly quotas, logo upload
- **Admin → Team** — team members with WhatsApp numbers
- **Admin → Content Calendar** — schedule tasks (date, brand, hook, assignee role)
- **Admin → Approvals** — review submissions, approve / reject with comments
- **Designer / AI Video Maker / Video Editor** — 3-Day view (Today, Tomorrow, Day After) with submission link
- **Settings** — daily send time, manual "Send WhatsApp now" trigger, notification log

## WhatsApp automation

A background `APScheduler` job runs daily at `DAILY_SEND_TIME` and pushes each member
their tasks for *today*. Transports tried in order: Twilio → Webhook → pywhatkit.
If all fail, the failure is logged in `notification_log` — the app never crashes.

Message format:
> Hi {Name}, your tasks for today are: 1. {Brand} - {Idea}, 2. {Brand} - {Idea}. Please update status on the portal.

## Files

- `app.py` — single-file Streamlit app (UI + DB + scheduler + WhatsApp)
- `schema.sql` — DB schema (auto-applied on startup)
- `requirements.txt` — Python deps
- `.env.example` — config template
